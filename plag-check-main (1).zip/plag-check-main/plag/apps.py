from django.apps import AppConfig


class PlagConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'plag'
