from django.contrib import admin
from .models import Query

# Register your models here.
admin.site.register(Query)