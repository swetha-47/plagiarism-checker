python -m venv venv   --> For installing Virtual Environment  --

cd venv/scripts && activate && cd ../../   -->For activating virtual environment  

pip install django -->For installing django

python manage.py runserver -->For Running server
